CKEDITOR.editorConfig = function( config ){
	config.skin = 'moono',
	config.disableNativeSpellChecker = true,
	config.scayt_autoStartup = true,
	};
